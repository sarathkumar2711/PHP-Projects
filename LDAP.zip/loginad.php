
 
<!DOCTYPE html>
<html>
	<head>
		<title>Login Authentication</title>
	</head>
		<body>
			<form action="ldap.php" method="post" align="center">
			<h2>Login Page with Active Directory</h2>
			<input type="text" placeholder="Enter Username" name="username" size="30"><br><br>
			<input type="password" placeholder="Enter Password" name="password" size="30"><br><br>
			<input type="submit" name="Login">
			
			</form>
		</body>
</html>
